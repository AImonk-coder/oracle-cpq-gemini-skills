# Pricing Engine & Related (official)

Primary source: https://help.bigmachines.com/cpq/Content/Manage_Pricing/

## Strategic Direction

Pricing Engine (Pricing Portal) is the modern, preferred way to handle pricing. It consolidates Price Models, Pricing Rules, Pricing Attributes, Charge Definitions, etc., under a Redwood UI.

Legacy pure-BML pricing scripts still work but are no longer the strategic path for new implementations.

## Price Model Types

- **Price List** – absolute prices under simple conditions
- **Discount List** – discount adjustments
- **Markup List** – markup / uplift adjustments
- **Advanced** – scripting support for charges and extensible output (preferred advanced path)
- **Advanced (Legacy)** – older BML-based Price Models

## Dynamic Pricing Types

- Static (None)
- Volume Pricing
- (and others documented in Price Models topic)

## Pricing Options (key toggles)

Located in Pricing Portal → Pricing Options. Examples:
- Transfer Price Model JSON to Commerce
- Apply Only the First Matching Price Model
- Enable Charge Definitions
- Enable Currency Conversion in Pricing Engine
- Enable incremental pricing in quoting
- Scripting hooks (before/after Pricing Engine BML)

## Key Distinctions

| Method              | Productized | Visibility in Commerce / Config / REST |
|---------------------|-------------|----------------------------------------|
| Pricing Engine      | Yes         | Full                                   |
| Formulas            | Custom      | Limited                                |
| BML (Data Tables)   | Custom      | Context-dependent                      |

Prefer Pricing Engine + Price Models for new work. Use BML/Formulas only when the Engine cannot express the required logic.