# BML Core Reference (from official help)

Source: https://help.bigmachines.com/cpq/Content/BML/

## Critical Null/Blank Rule (appears on nearly every function page)

- NULL and blank Integer values are treated as separate values:
  - NULL = 0
  - Blank = ""
- Using NULL as an attribute value is strongly discouraged.
- Always test for both when writing defensive logic.

## Array Limits

- 1-D arrays: maximum 1000 columns.
- 2-D arrays: maximum 1000 rows × 50 columns (default).
- Default BML row size limit 5000; column size 50. Increase via My Oracle Support ticket.
- Negative size or NaN (−999999) throws RuntimeException.
- Size = jNaN initializes size 0.

## Key Categories & Common Functions

### Arrays
append, boolean[n]/boolean[n][n], float[n]/float[n][n], integer[n]/integer[n][n], string[n]/string[n][n], date[n]/date[n][n], findinarray, isempty, max, min, range, remove, reverse, sizeofarray, sort, bytearray

### Dictionaries
dict, dict<anytype>, put, get, containskey, keys

### Conditional
if, if...else, if...else...if, for...loop, break, continue

### String
atof, atoi, decodebase64, encodebase64, endswith, find, formatascurrency, getcurrencyvalue, html, join, isnumber, len, lower, replace, split, startswith, string, substring, trim, upper

### Math
acos, asin, atan, ceil, cos, cosh, exp, fabs, fmod, hypot, integer, ... (see Math.htm)

### Dates
adddays, addmonths, comparedates, datetostr, getcurrenttimeinmillis, getdate, getdiffindays, getstrdate, ...

### Direct DB Access
bmql (preferred), getboolean, getdate, getfloat, getint, getmessage, getstr, haserror, ...
Deprecated: getpartsdata, gettabledata

### Others (selected)
addpartstotransaction, addtotransaction, getconfigattrvalue, getoldvalue, getreasonstatus, getuuid, importtransactiondata, invoke, isnull, logtime, setattributevalue, stringbuilder / sbappend / sbtostring, throwerror

### BOM Mapping
applybom, calculateconfiguration, calculatedeltabom, convertbomtoflat, convertbomtohier, getbom, getconfigbom, ...

### Constants (BM_*)
Many BM_CM_RULES_*, BM_REASON_STATUS_*, BM_REMOTE_APPROVAL_STATUS_*, BM_UNCHANGED_*, etc. See Others-Constants.htm.

## Libraries

- **Util BML Library**: callable from anywhere in CPQ. Admin Home → Developer Tools & Utilities → BML Library.
- **Commerce Library Functions**: 1:1 with a main-document + sub-document pair. Only accessible to that pair.

## Dynamic BMQL

Use dynamic variables for column names, table names, and WHERE clauses. Values are validated and substituted at runtime. Prefer over string concatenation to reduce injection risk and improve maintainability.

## Performance Notes

- BML compiler uses StringBuilders internally; large scripts may hit size limits (contact Support to adjust).
- Avoid looping every line item when a set-based approach or JSON array helpers exist.
- Prefer native array/JSON helpers and library functions over repeated attribute access.