---
name: oracle-cpq
description: Oracle CPQ (BigMachines) domain skill. Use when working with Oracle CPQ Configuration, Pricing Engine, Commerce Processes, BML scripting, BMQL, BOM Mapping, Approvals, REST APIs, Asset-Based Ordering, or any task that requires accurate CPQ admin or runtime behavior. Treat https://help.bigmachines.com/cpq/ as the single source of truth. Trigger on BML, BMQL, CPQ, BigMachines, Price Models, Pricing Rules, Commerce Process, Standard Process, Configuration rules, BOM mapping, or requests to write/debug CPQ scripts.
---

# Oracle CPQ

## Source of Truth

Always treat the official Oracle CPQ Help as authoritative:

- Base URL: https://help.bigmachines.com/cpq/
- Prefer the latest documented behavior (Standard Process, Redwood UI, Pricing Engine).
- When generating or reviewing BML, BMQL, formulas, rules, or integration payloads, match the documented function signatures, return types, null/blank handling, and limits exactly.
- If documentation and common practice conflict, follow the help site. Do not invent syntax.

Key reference entry points (load on demand via open_page or search):

- BML Overview: /Content/BML/BMLOverview.htm
- BML Functions List: /Content/BML/FunctionsScripts/BMLFunctionsList.htm
- Array Functions: /Content/BML/FunctionsScripts/Arrays.htm
- Dictionary Functions: /Content/BML/FunctionsScripts/Dictionary.htm
- Conditional: /Content/BML/FunctionsScripts/Conditional.htm
- String, Math, Dates, Direct DB Access (bmql), Others, BOM Mapping, JSON, etc. under /Content/BML/FunctionsScripts/
- Commerce Library Functions and Util BML Library
- Pricing Engine / Pricing Portal / Price Models
- Commerce Process / Standard Process
- Configuration / Product Hierarchy / BOM Mapping Rules

## Core Rules for All Responses

1. **Never invent BML functions or syntax.** Use only functions listed in the official BML Functions List and the category pages.
2. **Null vs blank is critical.** NULL (numeric 0 for integers in some contexts) and blank ("") are distinct. Official note appears on almost every function page: "NULL and blank Integer values are treated as separate values. NULL=0, Blank=\"\". Using NULL as an attribute value is strongly discouraged."
3. **Prefer library functions** (Util BML Library or Commerce Library) for reusable logic. Document when a function should live in Util vs Commerce library.
4. **Performance.** Avoid looping over all line items when possible. Prefer set-based BMQL or native array/JSON helpers. Note documented array size limits (1-D max 1000 columns; 2-D max 1000 rows × 50 columns by default).
5. **Standard Process first.** For new Commerce work default to the Standard Process (introduced 23B) unless the user explicitly works on a classic/blank process.
6. **Pricing Engine is strategic.** Prefer Price Models + Pricing Rules + Pricing Attributes over pure BML pricing scripts when the use case fits.
7. **When uncertain,** open the specific help page or search site:help.bigmachines.com before answering. Cite the topic name and path.

## BML Scripting Guidelines

- Data types: string, integer, float, boolean, date, arrays (1-D/2-D of those types), dictionaries (typed or anytype), JSON objects/arrays.
- **Logical operators (strict):** Use only the words `AND`, `OR`, `NOT`.  
  - Never use C/Java-style `||`, `&&`, or `!`.  
  - Example: `return (total > 50000) OR (discountPercent > 15);`
- Common patterns:
  - Initialize arrays with `string[n]`, `float[n]`, etc., or use `append`.
  - Dictionaries: `dict("string")`, `put`, `get`, `containskey`, `keys`.
  - Conditionals: `if`, `if...else`, `if...else...if` (use `elif`), `for...loop`, `break`, `continue`.
  - BMQL for data tables and system tables (preferred over deprecated gettabledata / getpartsdata).
  - Dynamic BMQL variables for safe parameterization.
- Always validate return types match the attribute or library function signature.
- For Commerce advanced functions (Modify, Auto Update, Default, etc.) respect document context (main vs sub-document / line).
- Use `throwerror` for controlled failures; `isnull` for null checks.
- StringBuilder helpers (`stringbuilder`, `sbappend`, `sbtostring`) exist for performance on large string work.
- HTML attributes cannot be set via BML.

## Common Task Patterns

**Write or fix BML**
- Confirm the exact function signatures from the Functions List.
- Show minimal complete example that can be pasted into the Function Editor.
- Note required library context (Util vs Commerce) and any dependent attributes.
- Call out null/blank and array-size gotchas.

**Pricing**
- Distinguish Price Models (Price List / Discount List / Markup List / Advanced), Pricing Rules, Pricing Attributes, and legacy BML pricing.
- Prefer Pricing Engine for new work.

**Configuration & BOM**
- Product hierarchy: All Product Families → Product Family → Product Line → Model.
- BOM Mapping rules (table-based + advanced BML).
- Configuration rules, flows, attributes.

**Commerce**
- Standard Process components, actions, workflow steps, approvals (serial/parallel), library functions.
- Transaction arrays / array sets and JSON reference syntax.

**Integrations & REST**
- Prefer documented REST versions; note the `/cpq/` path on Fusion sites.
- Integration Center (eSignature, OIC, Remote Approval, etc.).

## Response Style

- Be precise and code-ready.
- When showing BML, use the exact casing and operators from the docs.
- If a requested behavior is not supported or requires a Service Request / My Oracle Support ticket (e.g., raising array limits, disabling StringBuilder optimization), state that clearly.
- Link or name the official topic so the user can verify.

## Anti-patterns to Avoid

- Inventing functions that do not appear in the BML Functions List.
- Treating blank and NULL as interchangeable.
- Recommending deprecated functions (getpartsdata, gettabledata).
- Ignoring Standard Process / Redwood when the user is on a modern site.
- Giving generic programming advice that conflicts with BML’s specific semantics.